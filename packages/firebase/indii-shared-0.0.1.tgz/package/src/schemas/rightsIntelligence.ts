import { z } from 'zod';
import { EvidenceReferenceSchema, ProvenanceSchema, RightsClaimTypeSchema } from './musicEntity.js';

const Id = z.string().trim().min(1).max(200);
const EXTERNAL_ENTITY_REFERENCE_PREFIX = /^(?:isrc|iswc|upc|ean|icpn|ipi|isni|dpid|grid|catalog(?:_number)?|platform_id|proprietary|spotify|apple(?:_music)?|youtube|tiktok|instagram):/i;
const EXTERNAL_ENTITY_REFERENCE_VALUE = /^(?:[A-Z]{2}[A-Z0-9]{3}\d{7}|T-\d{3}\.\d{3}\.\d{3}-\d|\d{8,14})$/i;
const CanonicalEntityReference = z.string().trim().min(1).max(160).refine(
  value => !EXTERNAL_ENTITY_REFERENCE_PREFIX.test(value) && !EXTERNAL_ENTITY_REFERENCE_VALUE.test(value),
  'Canonical entity references must use indii internal IDs, not external identifiers.',
);
const IsoDateTime = z.string().datetime();

export const RightsTruthStateSchema = z.enum([
  'KNOWN', 'DECLARED', 'DETECTED', 'DOCUMENTED', 'VERIFIED',
  'UNKNOWN', 'DISPUTED', 'UNRESOLVED',
]);
export type RightsTruthState = z.infer<typeof RightsTruthStateSchema>;

export const RightsInterestSchema = z.object({
  interestId: Id,
  targetEntityId: CanonicalEntityReference,
  partyEntityId: CanonicalEntityReference,
  interestType: z.enum(['MASTER_OWNER', 'WRITER', 'COMPOSER', 'PUBLISHER', 'ADMINISTRATOR']),
  sharePercentage: z.number().min(0).max(100).optional(),
  territoryCodes: z.array(z.string().trim().min(1).max(32)).max(300).default([]),
  state: RightsTruthStateSchema,
  provenance: ProvenanceSchema,
}).strict();
export type RightsInterest = z.infer<typeof RightsInterestSchema>;

export const ThirdPartyUseSchema = z.object({
  useId: Id,
  targetRecordingEntityId: CanonicalEntityReference,
  useType: z.enum(['SAMPLE', 'COVER', 'INTERPOLATION']),
  sourceEntityId: CanonicalEntityReference.optional(),
  description: z.string().trim().min(1).max(2000),
  state: RightsTruthStateSchema,
  exclusiveRightsConfirmed: z.boolean().default(false),
  provenance: ProvenanceSchema,
  evidence: z.array(EvidenceReferenceSchema).max(100).default([]),
}).strict();
export type ThirdPartyUse = z.infer<typeof ThirdPartyUseSchema>;

/**
 * Explicit scope for an AI-use grant. `UNSPECIFIED` is a recorded gap, never
 * shorthand for permission. Provider IDs refer to canonical Organization IDs;
 * model identifiers remain namespaced external identifiers, not entity keys.
 */
export const AIUseScopeSchema = z.object({
  modality: z.enum(['GENERATIVE', 'NON_GENERATIVE']),
  purposes: z.array(z.enum(['TRAINING', 'FINE_TUNING', 'EVALUATION', 'INFERENCE'])).min(1).max(20),
  materials: z.array(z.enum([
    'SOUND_RECORDING', 'MUSICAL_WORK', 'LYRICS', 'METADATA', 'ARTIST_NAME', 'VOICE', 'LIKENESS', 'PERFORMANCE',
  ])).min(1).max(20),
  modelScope: z.discriminatedUnion('type', [
    z.object({ type: z.literal('NAMED_MODELS'), modelIdentifiers: z.array(z.string().trim().min(1).max(512)).min(1).max(100) }).strict(),
    z.object({ type: z.literal('PROVIDERS'), providerOrganizationEntityIds: z.array(CanonicalEntityReference).min(1).max(100) }).strict(),
    z.object({ type: z.literal('UNSPECIFIED') }).strict(),
  ]),
  commercialUse: z.enum(['ALLOWED', 'PROHIBITED', 'UNSPECIFIED']),
  sublicensing: z.enum(['ALLOWED', 'PROHIBITED', 'UNSPECIFIED']),
}).strict();
export type AIUseScope = z.infer<typeof AIUseScopeSchema>;

export const RightsGrantRightSchema = z.union([RightsClaimTypeSchema, z.literal('AI_USE')]);
export type RightsGrantRight = z.infer<typeof RightsGrantRightSchema>;

export const RightsGrantSchema = z.object({
  grantId: Id,
  subjectEntityId: CanonicalEntityReference,
  grantorEntityId: CanonicalEntityReference,
  granteeEntityId: CanonicalEntityReference,
  rights: z.array(RightsGrantRightSchema).min(1).max(20),
  aiUseScope: AIUseScopeSchema.optional(),
  territoryCodes: z.array(z.string().trim().min(1).max(32)).max(300).default([]),
  exclusive: z.boolean(),
  validFrom: z.string().date().optional(),
  validThrough: z.string().date().optional(),
  state: RightsTruthStateSchema,
  provenance: ProvenanceSchema,
  evidence: z.array(EvidenceReferenceSchema).max(100).default([]),
}).strict().superRefine((grant, ctx) => {
  if (grant.validFrom && grant.validThrough && grant.validThrough < grant.validFrom) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['validThrough'], message: 'validThrough cannot precede validFrom.' });
  }
  const includesAiUse = grant.rights.includes('AI_USE');
  if (includesAiUse && !grant.aiUseScope) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['aiUseScope'], message: 'AI_USE grants require an explicit modality, purpose, material, model, and terms scope.' });
  }
  if (!includesAiUse && grant.aiUseScope) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['aiUseScope'], message: 'AI-use scope is only valid when the grant explicitly includes AI_USE.' });
  }
});
export type RightsGrant = z.infer<typeof RightsGrantSchema>;

export const AIUseReviewStatusSchema = z.enum([
  'UNKNOWN',
  'REVIEW_REQUIRED',
  'DISPUTED',
  'EXPIRED',
  'NOT_YET_VALID',
  'EVIDENCE_BACKED_REQUIRES_HUMAN_REVIEW',
]);
export type AIUseReviewStatus = z.infer<typeof AIUseReviewStatusSchema>;

/** A review projection only: there is intentionally no permission/clearance status. */
export const AIUseGrantReviewSchema = z.object({
  grantId: Id,
  subjectEntityId: Id,
  state: RightsTruthStateSchema,
  provenanceState: ProvenanceSchema.shape.state,
  evidenceCount: z.number().int().nonnegative(),
  scope: AIUseScopeSchema,
  status: AIUseReviewStatusSchema,
  requiresHumanReview: z.literal(true),
  executionAuthorized: z.literal(false),
}).strict();
export type AIUseGrantReview = z.infer<typeof AIUseGrantReviewSchema>;

export const RightsEvidenceVaultSchema = z.object({
  entityId: CanonicalEntityReference,
  evidence: z.array(EvidenceReferenceSchema).max(1000).default([]),
}).strict();
export type RightsEvidenceVault = z.infer<typeof RightsEvidenceVaultSchema>;

export const RightsIntelligenceInputSchema = z.object({
  targetEntityId: CanonicalEntityReference,
  interests: z.array(RightsInterestSchema).max(1000).default([]),
  thirdPartyUses: z.array(ThirdPartyUseSchema).max(1000).default([]),
  grants: z.array(RightsGrantSchema).max(1000).default([]),
  evidenceVaults: z.array(RightsEvidenceVaultSchema).max(1000).default([]),
}).strict();
export type RightsIntelligenceInput = z.infer<typeof RightsIntelligenceInputSchema>;

export const RightsFindingSchema = z.object({
  code: z.enum([
    'MASTER_OWNERSHIP_UNKNOWN', 'MASTER_SPLITS_INVALID', 'COMPOSITION_OWNERSHIP_UNKNOWN',
    'COMPOSITION_SPLITS_INVALID', 'PUBLISHER_SPLITS_INVALID', 'THIRD_PARTY_USE_UNRESOLVED', 'EXCLUSIVE_RIGHTS_UNCONFIRMED',
    'GRANT_UNRESOLVED', 'EVIDENCE_MISSING', 'RIGHTS_INTEREST_UNRESOLVED', 'CATALOG_IMPORT_UNRESOLVED',
  ]),
  severity: z.enum(['INFO', 'REVIEW', 'BLOCKING']),
  entityId: Id,
  message: z.string().trim().min(1).max(2000),
  requiresHumanReview: z.boolean(),
}).strict();
export type RightsFinding = z.infer<typeof RightsFindingSchema>;

export const RightsIntelligenceReportSchema = z.object({
  schemaVersion: z.literal('rights-intelligence.v1'),
  targetEntityId: Id,
  masterShareTotal: z.number().min(0),
  compositionShareTotal: z.number().min(0),
  publisherShareTotal: z.number().min(0),
  findings: z.array(RightsFindingSchema).max(5000),
  /** Missing AI-use data stays UNKNOWN; documented data still requires a human/legal review. */
  aiUseStatus: AIUseReviewStatusSchema.default('UNKNOWN'),
  aiUseReviews: z.array(AIUseGrantReviewSchema).max(1000).default([]),
  aiUseExecutionAuthorized: z.literal(false).default(false),
  releaseReviewRequired: z.boolean(),
  contentIdAutomaticSubmissionEligible: z.boolean(),
  evaluatedAt: IsoDateTime,
}).strict();
export type RightsIntelligenceReport = z.infer<typeof RightsIntelligenceReportSchema>;

function isAuthoritativeAssertion(
  state: RightsTruthState,
  provenance: z.infer<typeof ProvenanceSchema>,
  hasEvidence: boolean,
): boolean {
  if (!hasEvidence) return false;
  return (state === 'DOCUMENTED' && provenance.state === 'DOCUMENTED' && provenance.sourceType === 'DOCUMENT')
    || (state === 'VERIFIED' && provenance.state === 'EXTERNAL_VERIFIED' && provenance.sourceType === 'EXTERNAL_SERVICE');
}

/** Deterministic preflight. It reports gaps and never upgrades truth or executes a filing. */
export function evaluateRightsIntelligence(input: RightsIntelligenceInput, evaluatedAt: string): RightsIntelligenceReport {
  const parsed = RightsIntelligenceInputSchema.parse(input);
  const findings: RightsFinding[] = [];
  const master = parsed.interests.filter((interest) => interest.interestType === 'MASTER_OWNER');
  const composition = parsed.interests.filter((interest) => ['WRITER', 'COMPOSER'].includes(interest.interestType));
  const publishers = parsed.interests.filter((interest) => interest.interestType === 'PUBLISHER');
  const sum = (interests: RightsInterest[]) => interests.reduce((total, interest) => total + (interest.sharePercentage ?? 0), 0);
  const masterShareTotal = sum(master);
  const compositionShareTotal = sum(composition);
  const publisherShareTotal = sum(publishers);

  if (master.length === 0) findings.push({ code: 'MASTER_OWNERSHIP_UNKNOWN', severity: 'BLOCKING', entityId: parsed.targetEntityId, message: 'Master ownership has not been declared or documented.', requiresHumanReview: true });
  else if (Math.abs(masterShareTotal - 100) > 0.01) findings.push({ code: 'MASTER_SPLITS_INVALID', severity: 'BLOCKING', entityId: parsed.targetEntityId, message: `Master ownership totals ${masterShareTotal}%; review is required before authoritative use.`, requiresHumanReview: true });

  if (composition.length === 0) findings.push({ code: 'COMPOSITION_OWNERSHIP_UNKNOWN', severity: 'REVIEW', entityId: parsed.targetEntityId, message: 'Composition ownership and writers are unknown.', requiresHumanReview: true });
  else if (Math.abs(compositionShareTotal - 100) > 0.01) findings.push({ code: 'COMPOSITION_SPLITS_INVALID', severity: 'BLOCKING', entityId: parsed.targetEntityId, message: `Composition interests total ${compositionShareTotal}%; review is required.`, requiresHumanReview: true });
  if (publishers.length > 0 && Math.abs(publisherShareTotal - 100) > 0.01) findings.push({ code: 'PUBLISHER_SPLITS_INVALID', severity: 'BLOCKING', entityId: parsed.targetEntityId, message: `Publisher interests total ${publisherShareTotal}%; review is required.`, requiresHumanReview: true });

  const vaultEntities = new Set(parsed.evidenceVaults.filter((vault) => vault.evidence.length > 0).map((vault) => vault.entityId));
  for (const rightsInterest of [...master, ...composition, ...publishers]) {
    const hasEvidence = rightsInterest.provenance.evidence.length > 0
      || vaultEntities.has(rightsInterest.targetEntityId)
      || vaultEntities.has(rightsInterest.partyEntityId);
    const authoritative = isAuthoritativeAssertion(rightsInterest.state, rightsInterest.provenance, hasEvidence);
    if (!authoritative) {
      const disputed = rightsInterest.state === 'DISPUTED' || rightsInterest.state === 'UNRESOLVED'
        || rightsInterest.provenance.state === 'DISPUTED';
      findings.push({
        code: 'RIGHTS_INTEREST_UNRESOLVED',
        severity: disputed ? 'BLOCKING' : 'REVIEW',
        entityId: rightsInterest.targetEntityId,
        message: `${rightsInterest.interestType.toLowerCase().replace('_', ' ')} interest ${rightsInterest.interestId} is ${rightsInterest.state.toLowerCase()}; non-authoritative rights cannot be treated as cleared.`,
        requiresHumanReview: true,
      });
    }
    if ((rightsInterest.state === 'DOCUMENTED' || rightsInterest.state === 'VERIFIED') && !hasEvidence) {
      findings.push({ code: 'EVIDENCE_MISSING', severity: 'REVIEW', entityId: rightsInterest.targetEntityId, message: `No evidence supports documented interest ${rightsInterest.interestId}.`, requiresHumanReview: true });
    }
  }

  for (const use of parsed.thirdPartyUses) {
    const authoritative = isAuthoritativeAssertion(use.state, use.provenance, use.evidence.length > 0 || use.provenance.evidence.length > 0);
    if (!authoritative) findings.push({ code: 'THIRD_PARTY_USE_UNRESOLVED', severity: 'BLOCKING', entityId: use.targetRecordingEntityId, message: `${use.useType.toLowerCase()} rights are ${use.state.toLowerCase()} or lack matching documented provenance and evidence.`, requiresHumanReview: true });
    if (!use.exclusiveRightsConfirmed) findings.push({ code: 'EXCLUSIVE_RIGHTS_UNCONFIRMED', severity: 'BLOCKING', entityId: use.targetRecordingEntityId, message: `${use.useType.toLowerCase()} material prevents automatic Content ID submission until exclusive-rights eligibility is reviewed.`, requiresHumanReview: true });
    if (use.evidence.length === 0) findings.push({ code: 'EVIDENCE_MISSING', severity: 'REVIEW', entityId: use.targetRecordingEntityId, message: `No evidence is attached to the ${use.useType.toLowerCase()} record.`, requiresHumanReview: true });
  }
  const aiUseReviews = parsed.grants
    .filter((grant) => grant.rights.includes('AI_USE'))
    .map((grant) => {
      // Schema refinement guarantees scope for every AI_USE grant.
      const scope = grant.aiUseScope!;
      const evaluatedDate = evaluatedAt.slice(0, 10);
      const state: AIUseReviewStatus = grant.state === 'DISPUTED' || grant.state === 'UNRESOLVED'
        || grant.provenance.state === 'DISPUTED'
        ? 'DISPUTED'
        : grant.validThrough && grant.validThrough < evaluatedDate
          ? 'EXPIRED'
          : grant.validFrom && grant.validFrom > evaluatedDate
            ? 'NOT_YET_VALID'
            : isAuthoritativeAssertion(grant.state, grant.provenance, grant.evidence.length > 0 || grant.provenance.evidence.length > 0)
              ? 'EVIDENCE_BACKED_REQUIRES_HUMAN_REVIEW'
              : 'REVIEW_REQUIRED';
      return AIUseGrantReviewSchema.parse({
        grantId: grant.grantId,
        subjectEntityId: grant.subjectEntityId,
        state: grant.state,
        provenanceState: grant.provenance.state,
        evidenceCount: new Set([...grant.evidence, ...grant.provenance.evidence].map((evidence) => evidence.id)).size,
        scope,
        status: state,
        requiresHumanReview: true,
        executionAuthorized: false,
      });
    });
  const aiUseStatus: AIUseReviewStatus = aiUseReviews.length === 0
    ? 'UNKNOWN'
    : aiUseReviews.some((review) => review.status === 'DISPUTED')
      ? 'DISPUTED'
      : aiUseReviews.some((review) => review.status !== 'EVIDENCE_BACKED_REQUIRES_HUMAN_REVIEW')
        ? 'REVIEW_REQUIRED'
        : 'EVIDENCE_BACKED_REQUIRES_HUMAN_REVIEW';

  for (const grant of parsed.grants) {
    // AI training/use permission is independently scoped. It must not block or
    // authorize ordinary release readiness. Mixed grants still receive the
    // existing review for their non-AI rights.
    if (!grant.rights.some((right) => right !== 'AI_USE')) continue;
    if (!isAuthoritativeAssertion(grant.state, grant.provenance, grant.evidence.length > 0 || grant.provenance.evidence.length > 0)) {
      findings.push({ code: 'GRANT_UNRESOLVED', severity: 'BLOCKING', entityId: grant.subjectEntityId, message: `Rights grant ${grant.grantId} is ${grant.state.toLowerCase()} or lacks matching documented provenance and evidence.`, requiresHumanReview: true });
    }
  }

  const allCoreInterestsAuthoritative = [...master, ...composition, ...publishers].every((interest) => isAuthoritativeAssertion(
    interest.state,
    interest.provenance,
    interest.provenance.evidence.length > 0 || vaultEntities.has(interest.targetEntityId) || vaultEntities.has(interest.partyEntityId),
  ));
  const releaseReviewRequired = findings.some((finding) => finding.requiresHumanReview);
  return RightsIntelligenceReportSchema.parse({
    schemaVersion: 'rights-intelligence.v1', targetEntityId: parsed.targetEntityId,
    masterShareTotal, compositionShareTotal, publisherShareTotal, findings,
    aiUseStatus, aiUseReviews, aiUseExecutionAuthorized: false,
    releaseReviewRequired,
    contentIdAutomaticSubmissionEligible: !releaseReviewRequired
      && parsed.thirdPartyUses.length === 0
      && allCoreInterestsAuthoritative,
    evaluatedAt,
  });
}
