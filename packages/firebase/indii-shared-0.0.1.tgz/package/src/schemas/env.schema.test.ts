import { describe, it, expect } from 'vitest';
import { CommonEnvSchema } from './env.schema.js';

describe('CommonEnvSchema', () => {
    it('should validate valid env', () => {
        const data = {
            apiKey: 'key',
            projectId: 'proj',
        };
        const result = CommonEnvSchema.parse(data);
        expect(result.location).toBe('us-central1');
        expect(result.functionsRegion).toBe('us-central1');
        expect(result.useVertex).toBe(true);
    });

    it('should allow missing raw AI apiKey and require projectId', () => {
        const data = {
            apiKey: '',
            projectId: ''
        };
        expect(() => CommonEnvSchema.parse(data)).toThrow();

        const validWithoutRawKey = CommonEnvSchema.parse({ projectId: 'proj' });
        expect(validWithoutRawKey.apiKey).toBe('');
    });
});
